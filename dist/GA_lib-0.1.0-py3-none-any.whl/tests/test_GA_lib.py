from GA_lib import GA 

def test_vetor():
    GA.vetor([1,2], [7, 10]) == [6, 8]

def test_modulo():
    GA.modulo([5, 0]) == 5.0

def test_distancia_ponto_linha():
    GA.distancia_ponto_linha([1,2,5], [-3, -1, -2], [-2, 8, -1]) == 7.967840766888259

def test_produto_escalar():
    GA.produto_escalar([1,1,1], [1,1,1]) == 3

def test_produto_vetorial():
    GA.produto_vetorial([-7, -2, -1], [-5, -5, -5]) == [5, -30,  25]

def test_distancia_ponto_plano():
    GA.distancia_ponto_plano([-3, -6, -1], [-5, -3, -5], [1, 5, 3], [3, -5, 2]) == 4.910618416080245

def test_angulo_entre_vetores():
    GA.angulo_entre_vetores([ 5, -30, 25], [25, -15, -15]) == 81.08675878843925

def test_distancia_entre_planos():
    GA.distancia_entre_planos(-9, -4, 2, 20, 54) == 3.383126446713963
